// migrating the appropriate contracts
var SquareVerifier = artifacts.require("./Verifier.sol");
var SolnSquareVerifier = artifacts.require("./SolnSquareVerifier.sol");
var ERC721Mintable = artifacts.require("./CustomERC721Token");
module.exports = function(deployer) {
  deployer.deploy(SquareVerifier) .then(() => {
    deployer.deploy(ERC721Mintable);
    deployer.deploy(SolnSquareVerifier,SquareVerifier.address);
  })
};
