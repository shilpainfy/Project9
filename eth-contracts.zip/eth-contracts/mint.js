
//const TruffleContract = require('truffle-contract');
//const HDWalletProvider = require("truffle-hdwallet-provider");
const contract = require('../eth-contracts/build/contracts/SolnSquareVerifier.json');

const HDWalletProvider = require('truffle-hdwallet-provider');
const ABI = contract.abi;
const proofs = [
    require('../eth-contracts/Proofs/proof1'),
    require('../eth-contracts/Proofs/proof2'),
    require('../eth-contracts/Proofs/proof3'),
    require('../eth-contracts/Proofs/proof4'),
    require('../eth-contracts/Proofs/proof5'),
    require('../eth-contracts/Proofs/proof6'),
    require('../eth-contracts/Proofs/proof7'),
    require('../eth-contracts/Proofs/proof8'),
    require('../eth-contracts/Proofs/proof9'),
    require('../eth-contracts/Proofs/proof10'),
];

//var SolnSquareVerifier = artifacts.require('SolnSquareVerifier');
//const contract = artifacts.require('../eth-contracts/build/contracts/SolnSquareVerifier');

//declare variables for storing infura key, owner address and contract address, private key
const INFURA_KEY = '992e8958d80b4283a5118edfe4f89b55';
const OWNER_ADDRESS = '0x58522C7ff40A1336C820D24c8F79934ad0b15910';
const CONTRACT_ADDRESS = '0x0392ad045bb5db18fe0bf4839b6e81499f931931';
 var privateKeys = [
    "..."
  ];
var mnemonic='.... foster';

const web3 = require('web3');
const network = "rinkeby";

async function mintTokens() {
    let provider;
    if(network === "rinkeby") {
         provider=new HDWalletProvider(privateKeys, 'https://rinkeby.infura.io/v3/992e8958d80b4283a5118edfe4f89b55');
    }
    else if(network === "development") {
        provider= new web3.providers.WebsocketProvider("http://127.0.0.1:7545");
    }
    //const provider = new HDWalletProvider(mnemonic, 'https://rinkeby.infura.io/v3/992e8958d80b4283a5118edfe4f89b55');
    const web3Instance = new web3( provider);

   const contract = new web3Instance.eth.Contract(ABI, CONTRACT_ADDRESS, {gasLimit: "712388"});


    proofs.forEach(async function (proof, index) {
        console.log(index);
        // index = index+10;
        // console.log(proof.proof);
        // index = 0;
        try {
            const result = await contract.methods.mintNewNFT(
                OWNER_ADDRESS,
                index,
                proof.proof.A,
                proof.proof.A_p,
                proof.proof.B,
                proof.proof.B_p,
                proof.proof.C,
                proof.proof.C_p,
                proof.proof.H,
                proof.proof.K,
                proof.input).send({
                from: OWNER_ADDRESS,
                gas: 3900000
                // gas: 4993538
            });
            console.log("Mint Transaction: " + result.transactionHash);
        } catch (e) {
            console.log(e);
        }

    });
}

mintTokens();